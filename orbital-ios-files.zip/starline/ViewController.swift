//
//  ViewController.swift
//  starline
//
//  Created by sunshine on 9/12/22.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the view's delegate
        sceneView.delegate = self
        createBolt()
    }
    
    
    func createBolt(){
        let path = UIBezierPath()
        path.move(to: CGPoint(x: -5, y: 0))
        path.addQuadCurve(to: CGPoint(x: 5, y: 0), controlPoint: CGPoint(x: 0, y: 20))
        path.addLine(to: CGPoint(x: 4.9, y: 0))
        path.addQuadCurve(to: CGPoint(x: -4.9, y: 0), controlPoint: CGPoint(x: 0, y: 19.8))

        // Tweak for a smoother shape (lower is smoother)
        path.flatness = 0.05
        
        
        let shape = SCNShape(path: path, extrusionDepth: 0.1)
        let color = #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1)
        shape.firstMaterial?.diffuse.contents = color
        shape.chamferRadius = 0.1
        
        
        let boltNode = SCNNode(geometry: shape)
        boltNode.position.z = -1
        sceneView.scene.rootNode.addChildNode(boltNode)
        
        
        let g = SCNSphere(radius: 0.2)
        let ballColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
          g.firstMaterial?.diffuse.contents = ballColor
            g.segmentCount = 12
          let node = SCNNode(geometry: g)
          node.position = SCNVector3(x: 5, y: 0, z: -1)
        sceneView.scene.rootNode.addChildNode(node)
        
        let g2 = SCNSphere(radius: 0.2)
          g2.firstMaterial?.diffuse.contents = ballColor
            g2.segmentCount = 12
          let node2 = SCNNode(geometry: g2)
          node2.position = SCNVector3(x: 0, y: 18, z: -1)
        sceneView.scene.rootNode.addChildNode(node2)
        
        let g3 = SCNSphere(radius: 0.2)
          g3.firstMaterial?.diffuse.contents = ballColor
            g3.segmentCount = 12
          let node3 = SCNNode(geometry: g3)
        node3.position = SCNVector3(x: -5, y: 0, z: -1)
        sceneView.scene.rootNode.addChildNode(node3)
        
    
    }
     
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Pause the view's session
        sceneView.session.pause()
    }

    
}
